# RESPONSIVE Personal PORTFOLIO Website HTML CSS And JAVASCRIPT

## Video (https://youtu.be/J8g9gyzhEoM)

!["RESPONSIVE Personal PORTFOLIO Website HTML CSS And JAVASCRIPT"](https://raw.githubusercontent.com/ziddahedem/portfolio2/master/screenshot.png "RESPONSIVE Personal PORTFOLIO Website HTML CSS And JAVASCRIPT")
